# Simple Plants

Simple Plants is a lightweight Subnautica 1 mod that makes a few vanilla plant-derived resources occupy a single inventory slot.

## Description

This mod changes the inventory size of these items to `1x1`:

- Creepvine samples
- Creepvine seed clusters
- Blood oil

It does not add new items, recipes, prefabs, or configuration files. Existing saves are supported.

## Requirements

- Subnautica 1
- BepInEx 5
- Nautilus

## Installation

1. Copy `SimplePlants.dll` into `Subnautica/BepInEx/plugins/`.
2. Start the game.
3. Load a save.

## Compatibility

This mod changes vanilla `TechType` inventory metadata at startup.

If another mod edits the same item sizes later in the load order, the last mod to write the value wins.

## How It Works

The mod uses Nautilus' inventory sizing API:

```csharp
CraftDataHandler.SetItemSize(TechType, 1, 1);
```

## Changelog

### 1.0.0

- Initial release
- Creepvine samples, creepvine seed clusters, and blood oil now stack as `1x1`
